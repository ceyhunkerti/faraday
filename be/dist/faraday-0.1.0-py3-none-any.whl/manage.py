from app.cli import faraday


if __name__ == "__main__":
    faraday()
